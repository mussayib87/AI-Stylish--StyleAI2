import Groq from "groq-sdk";

/**
 * Server-only Groq client.
 *
 * IMPORTANT: this must read a plain (non "VITE_"-prefixed) env var via
 * process.env. Vite statically inlines any `VITE_*` variable into the
 * client bundle, so prefixing a secret API key with VITE_ would leak it
 * to the browser. Keep the name in sync with ai.server.ts's guard check.
 */
function assertServer() {
  if (typeof window !== "undefined") {
    throw new Error(
      "askStylist() was called from the browser. This module must only run on the server.",
    );
  }
}

let groqClient: Groq | null = null;

function getGroqClient(): Groq {
  if (groqClient) return groqClient;

  const apiKey = process.env["GROQ_API_KEY"];
  console.log("[DEBUG] getGroqClient: GROQ_API_KEY exists =", !!apiKey);

  if (!apiKey) {
    throw new Error("GROQ_API_KEY missing");
  }

  groqClient = new Groq({ apiKey });
  return groqClient;
}

export async function askStylist(
  message: string,
  wardrobe: any[]
) {
  console.log("[DEBUG] Entered askStylist");
  assertServer();

  try {
    const groq = getGroqClient();

    console.log("[DEBUG] Calling groq.chat.completions.create()");
    const completion = await groq.chat.completions.create({
      model: "llama-3.3-70b-versatile",
      messages: [
        {
          role: "system",
          content: `
You are StyleAI.
Only recommend clothes that exist in the user's wardrobe.
Explain your reasoning.
`,
        },
        {
          role: "user",
          content: `
Wardrobe:
${JSON.stringify(wardrobe)}

Question:
${message}
`,
        },
      ],
      temperature: 0.7,
    });
    console.log("[DEBUG] groq.chat.completions.create() succeeded");

    return completion.choices[0]?.message?.content ?? "";
  } catch (error) {
    console.error("[FULL ERROR] askStylist failed:", error);
    throw error;
  }
}
